import numpy as np

# Constants for the players
EMPTY = 0
PLAYER_X = 1
PLAYER_O = 2

# Evaluation scores
SCORES = {
    PLAYER_X: 1,
    PLAYER_O: -1,
    "tie": 0
}


class TicTacToeNode:
    def __init__(self, board, current_player):
        self.board = board
        self.current_player = current_player

    def is_terminal(self):
        if self.is_winner(PLAYER_X) or self.is_winner(PLAYER_O) or self.is_board_full():
            return True
        return False

    def evaluate(self):
        if self.is_winner(PLAYER_X):
            return SCORES[PLAYER_X]
        elif self.is_winner(PLAYER_O):
            return SCORES[PLAYER_O]
        else:
            return SCORES["tie"]

    def generate_children(self):
        children = []
        for i in range(3):
            for j in range(3):
                if self.board[i][j] == EMPTY:
                    child_board = np.copy(self.board)
                    child_board[i][j] = self.current_player
                    child_node = TicTacToeNode(child_board, self.get_next_player())
                    children.append(child_node)
        return children

    def get_next_player(self):
        return PLAYER_O if self.current_player == PLAYER_X else PLAYER_X

    def is_winner(self, player):
        for i in range(3):
            if np.all(self.board[i] == player):
                return True
            if np.all(self.board[:, i] == player):
                return True
        if np.all(np.diag(self.board) == player):
            return True
        if np.all(np.diag(np.fliplr(self.board)) == player):
            return True
        return False

    def is_board_full(self):
        return np.all(self.board != EMPTY)


def minimax_alpha_beta(node, depth, alpha, beta, maximizing_player):
    if depth == 0 or node.is_terminal():
        return node.evaluate()

    if maximizing_player:
        value = float("-inf")
        for child in node.generate_children():
            value = max(value, minimax_alpha_beta(child, depth - 1, alpha, beta, False))
            alpha = max(alpha, value)
            if beta <= alpha:
                break  # Beta cutoff
        return value
    else:
        value = float("inf")
        for child in node.generate_children():
            value = min(value, minimax_alpha_beta(child, depth - 1, alpha, beta, True))
            beta = min(beta, value)
            if beta <= alpha:
                break  # Alpha cutoff
        return value


def get_best_move(board):
    node = TicTacToeNode(board, PLAYER_O)
    best_value = float("-inf")
    best_move = None
    alpha = float("-inf")
    beta = float("inf")
    maximizing_player = False
    depth = 9

    for child in node.generate_children():
        value = minimax_alpha_beta(child, depth - 1, alpha, beta, maximizing_player)
        if value > best_value:
            best_value = value
            best_move = child.board

    return best_move


def print_board(board):
    for row in board:
        print(" | ".join(["X" if cell == PLAYER_X else "O" if cell == PLAYER_O else " " for cell in row]))
        print("-" * 9)


def check_winner(board):
    # Check rows and columns
    for i in range(3):
        if np.all(board[i] == PLAYER_X) or np.all(board[:, i] == PLAYER_X):
            return PLAYER_X
        if np.all(board[i] == PLAYER_O) or np.all(board[:, i] == PLAYER_O):
            return PLAYER_O

    # Check diagonals
    if np.all(np.diag(board) == PLAYER_X) or np.all(np.diag(np.fliplr(board)) == PLAYER_X):
        return PLAYER_X
    if np.all(np.diag(board) == PLAYER_O) or np.all(np.diag(np.fliplr(board)) == PLAYER_O):
        return PLAYER_O

    # No winner
    return EMPTY


def play_tic_tac_toe():
    # Initialize an empty Tic-Tac-Toe board
    board = np.zeros((3, 3), dtype=int)

    # Start the game with player X
    current_player = PLAYER_X

    while True:
        print("Current Board:")
        print_board(board)

        # Check if the game is over
        if np.all(board != EMPTY) or check_winner(board):
            print("Game Over!")
            break

        if current_player == PLAYER_X:
            # Player X's turn
            print("Player X's Turn:")
            row = int(input("Enter the row number (0, 1, or 2): "))
            col = int(input("Enter the column number (0, 1, or 2): "))

            # Check if the chosen position is valid
            if board[row][col] != EMPTY:
                print("Invalid move! Try again.")
                continue

            # Update the board
            board[row][col] = PLAYER_X
        else:
            # Computer's turn (Player O)
            print("Computer's Turn:")
            best_move = get_best_move(board)

            # Update the board
            board = best_move

        # Switch players
        current_player = PLAYER_O if current_player == PLAYER_X else PLAYER_X


play_tic_tac_toe()
